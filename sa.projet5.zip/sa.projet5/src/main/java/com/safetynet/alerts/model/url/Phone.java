package com.safetynet.alerts.model.url;

public class Phone {

    private String phone;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Phone(String phone) {
        this.phone = phone;
    }

}
